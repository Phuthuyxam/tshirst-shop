<?php

/**
 * Fired during plugin activation
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Ptx_Woo_Exporter
 * @subpackage Ptx_Woo_Exporter/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Ptx_Woo_Exporter
 * @subpackage Ptx_Woo_Exporter/includes
 * @author     phuthuyxam <phamphucit88@gmail.com>
 */
class Ptx_Woo_Exporter_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
        if(self::pluginRequirement()) {
            deactivate_plugins( plugin_basename( PTX_WOO_EXPORTER_URI ) );
            wp_die( __( 'My Plugin requires Woocomerce plugin', 'my-plugin' ) );
        }
	}
    public function admin_notice__error_install() {
        $errors = $this->pluginRequirement();
        ?>
        <div class="notice notice-success is-dismissible">
            <?php foreach ($errors as $err): ?>
                <p><?php _e( 'Error! '. $err, 'sample-text-domain' ); ?></p>
            <?php endforeach; ?>
        </div>
        <?php
    }

    public function pluginRequirement() {
        // check woo
        $error = false;
        if(!class_exists( 'WooCommerce' )) {
            $error['plugin_require'] = "Woocomerce is required";
        }
        return $error;
    }
}
