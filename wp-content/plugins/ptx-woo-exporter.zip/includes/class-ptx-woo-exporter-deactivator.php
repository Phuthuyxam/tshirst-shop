<?php

/**
 * Fired during plugin deactivation
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Ptx_Woo_Exporter
 * @subpackage Ptx_Woo_Exporter/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Ptx_Woo_Exporter
 * @subpackage Ptx_Woo_Exporter/includes
 * @author     phuthuyxam <phamphucit88@gmail.com>
 */
class Ptx_Woo_Exporter_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
