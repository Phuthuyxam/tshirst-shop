<?php
register_nav_menus(
    array(
        "main-menu"=>"Main Menu",
        "main-mobile"=>"Menu Mobile",
        "menu-top" => "Menu Top"
    )
);
?>