<?php
add_image_size( 'home_new_thumb', 280, 280, true );
add_image_size( 'home_new_thumb2', 231, 209, true );
?>